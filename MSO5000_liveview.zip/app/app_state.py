# app_state.py — holds shared flags
is_logging_active = False