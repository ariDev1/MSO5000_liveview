scpi_data = {
    "connected": False,
    "idn": "N/A",
    "system_info": "",
    "channel_info": {},   # { "CH1": {scale, offset, coupling, probe}, ... }
    "trigger_status": "",
}
